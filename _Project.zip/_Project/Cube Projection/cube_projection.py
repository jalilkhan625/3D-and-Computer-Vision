import numpy as np
import cv2 as cv
from os.path import isfile
from concurrent.futures import ThreadPoolExecutor as Pool

# Function to read coordinates from a CSV file
def load_coordinates(video_index: int) -> list[tuple[np.ndarray, np.ndarray]]:
    filename = f"./data/obj0{video_index}_marker.csv"
    data = np.loadtxt(filename, delimiter=",", usecols=(0, 2, 3, 4, 5, 6), skiprows=1)
    data[:, 0] = data[:, 0].astype(int)

    groups_by_frame = {}
    for row in data:
        frame_index = row[0]
        if frame_index not in groups_by_frame:
            groups_by_frame[frame_index] = [[], []]
        groups_by_frame[frame_index][0].append([row[1], row[2]])
        groups_by_frame[frame_index][1].append([row[3], row[4], row[5]])

    return [
        (
            np.array(coords[0], dtype=np.float32),
            np.array(coords[1], dtype=np.float32),
        )
        for coords in groups_by_frame.values()
    ]

# Global variables shared by threads

# Camera intrinsic parameters
K = np.array(
    [
        [1.66750771e03, 0.00000000e00, 9.54599045e02],
        [0.00000000e00, 1.66972683e03, 5.27926123e02],
        [0.00000000e00, 0.00000000e00, 1.00000000e00],
    ],
    dtype=np.float32,
)

# Distortion coefficient
dist_coef = np.array(
    [
        1.16577217e-01,
        -9.28944623e-02,
        7.15149511e-05,
        -1.80025974e-03,
        -1.24761932e-01,
    ],
    dtype=np.float32,
)

# Indices of the vertices that form each face of the cube
cube_faces = np.array(
    [
        (0, 1, 2, 3),
        (4, 5, 6, 7),
        (0, 3, 7, 4),
        (1, 2, 6, 5),
        (0, 1, 5, 4),
        (2, 3, 7, 6),
    ],
    dtype=np.int8,
)

# Define the 3D coordinates of the cube in object space
cube_pts = np.array(
    [
        (70.0, 0.0, 75.0),
        (0.0, -70.0, 75.0),
        (-70.0, 0.0, 75.0),
        (0.0, 70.0, 75.0),
        (70.0, 0.0, 169),
        (0.0, -70.0, 169),
        (-70.0, 0.0, 169),
        (0.0, 70.0, 169),
    ],
    dtype=np.float32,
)

# Variable use to store frames and coordinates
all_frames_and_coords = None

# Function for cube projection in a single frame
def cube_projection_frame(index: int) -> np.ndarray:
    global all_frames_and_coords
    frame, points_2d, points_3d = (
        cv.undistort(all_frames_and_coords[index][0], K, dist_coef),
        all_frames_and_coords[index][1][0],
        all_frames_and_coords[index][1][1],
    )
    all_frames_and_coords[index] = None

    _, rvec, tvec = cv.solvePnP(
        points_3d, points_2d, K, dist_coef, flags=cv.SOLVEPNP_IPPE
    )

    cube_pts_2d, _ = cv.projectPoints(cube_pts, rvec, tvec, K, dist_coef)

    cv.polylines(
        frame,
        [cube_pts_2d[face].reshape((-1, 2)).astype(int) for face in cube_faces],
        True,
        (0, 0, 255),
        thickness=3,
    )

    return frame

# Function for cube projection in frames
def cube_projection_frames(video_index: int, basic_path: str) -> None:
    global all_frames_and_coords

    video_path = f"{basic_path}{video_index}.mp4"
    vidcap = cv.VideoCapture(video_path)
    num_frames = int(vidcap.get(cv.CAP_PROP_FRAME_COUNT))

    (out_h, out_w) = int(vidcap.get(cv.CAP_PROP_FRAME_HEIGHT)), int(
        vidcap.get(cv.CAP_PROP_FRAME_WIDTH)
    )
    fps = vidcap.get(cv.CAP_PROP_FPS)

    coords_by_frame_dict = load_coordinates(video_index)

    all_frames_and_coords = np.empty((num_frames), dtype=object)
    for i in range(num_frames):
        ret, frame = vidcap.read()
        if not ret:
            break
        all_frames_and_coords[i] = (
            frame,
            coords_by_frame_dict[i],
        )
    vidcap.release()
    del coords_by_frame_dict

    with Pool() as pool:
        results = pool.map(
            cube_projection_frame,
            range(num_frames),
            chunksize=2,
        )

        out = cv.VideoWriter(
            f"{basic_path}{video_index}_cube.mp4",
            cv.VideoWriter_fourcc(*"mp4v"),
            fps,
            (out_w, out_h),
        )

        for processed_frame in results:
            out.write(processed_frame)

        out.release()

#choose video for processing
if __name__ == "__main__":
    print("Choose which video to process:")
    print("1. Video 1")
    print("2. Video 2")
    print("3. Video 3")
    print("4. Video 4")

    chosen_video = int(input("Enter the corresponding number: "))

    while chosen_video not in [1, 2, 3, 4]:
        chosen_video = int(input("Invalid input. Please enter a valid number: "))

    basic_path = "./data/obj0"

    coords_by_frame_dict = load_coordinates(chosen_video)
    cube_projection_frames(chosen_video, basic_path)
    print("Success")
