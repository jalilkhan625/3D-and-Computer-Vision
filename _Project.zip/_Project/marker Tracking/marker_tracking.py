import numpy as np
import cv2 as cv
from math import sqrt, acos, degrees, sin, cos, radians
from typing import Tuple

# Function to retrieve rotated labels
def retrieve_labels() -> dict[int, Tuple[float, float]]:
    """Return a dictionary that maps each possible turn table id/label to the corresponding 3D coordinates."""
    def rotation_pos(id: int) -> Tuple[float, float]:
        """Compute the rotation of the given label."""
        angle15 = radians(-15)
        qx = cos(angle15 * id) * 70
        qy = sin(angle15 * id) * 70
        return qx, qy

    return {marker_id: rotation_pos(marker_id) for marker_id in range(0, 24)}

# Function for the calculation of 2D Euclidean distance
def cal_euclidean_dist_2d(one: list[float], two: list[float]) -> float:
    """Computes the 2D euclidean distance between the given points."""
    dx = one[0] - two[0]
    dy = one[1] - two[1]
    return sqrt(dx * dx + dy * dy)

# Function to calculate angle(between 3 points)
def cal_angle(p1: list[int], p2: list[int], p3: list[int]) -> float:
    """Computes the angle between 3 points, where p3 will be the central point (the one which "hosts" the angle)."""
    # get distances
    a = cal_euclidean_dist_2d(p3, p1)
    b = cal_euclidean_dist_2d(p3, p2)
    c = cal_euclidean_dist_2d(p1, p2)

    # law of cosines: calculate angle, assuming a and b to be non-zero
    numer = c**2 - a**2 - b**2
    denom = -2 * a * b
    if denom == 0:
        denom = 0.000001
    rads = acos(numer / denom)
    degs = degrees(rads)

    # check if past 180 degrees, invert the angle.
    if p1[1] > p3[1]:
        degs = 360 - degs
    return degs

# Function to find concave angle
def concave_ang_finder(cv_points: np.ndarray) -> int:
    """Find the index of the concave angle in the given array of points."""
    # Remove the extra dimension intrinsic to Opencv points.
    points = cv_points.reshape(-1, 2)

    # the vectors are differences of coordinates
    # a points into the point, b out of the point
    a = points - np.roll(points, 1, axis=0)
    b = np.roll(a, -1, axis=0)  # same but shifted

    # The concave angle will be the only angle whose cross product will
    # be negative (and also the smallest).
    return np.argmin(np.cross(a, b))

# Function to sort contours in clockwise direction
def clockwise_sort_contours(contours: np.ndarray) -> np.ndarray:
    """Sort the given contours clockwise, by fitting the smallest possible circle around all their
    centres, and sorting them through their angles. Centres are used because they allow to establish
    with enough precision (for this use case) the direction of each contour/polygon."""
    centroids = []
    centers = []

    for cnt in contours:
        m = cv.moments(cnt)
        cx = int(m["m10"] / m["m00"])
        cy = int(m["m01"] / m["m00"])
        centers.append([cx, cy])
        centroids.append([[cx, cy], cnt])

    # find the circle which encompasses the centres.
    numped = np.array(centers)
    # Second value after tuple is radius, but is not required.
    (x, y), _ = cv.minEnclosingCircle(numped)
    middle = [x, y]
    offshoot = [x + 100, y]

    angles = [[cal_angle(cen[0], offshoot, middle), cen[0], cen[1]] for cen in centroids]

    # sort by angle
    final = sorted(angles, key=lambda a: a[0], reverse=True)

    # pull out just the contours
    contours = [clump[2] for clump in final]

    return contours

# Function to check continuity between markers
def markers_continuity_checker(markers_dictionary: list, current_index: int) -> bool:
    """Check whether the next marker is the real successor of the current marker.
    A real successor should be more distant than 120-y circa from the current marker."""
    act_y = markers_dictionary[current_index][0][0][0][0][1]
    next_y = markers_dictionary[(current_index + 1) % len(markers_dictionary)][0][0][0][0][1]
    diff_y = abs(next_y - act_y)
    return diff_y < 200

# Function to identify single circle marker
def single_cir_marker_locator(markers_dictionary: list, current_index: int) -> int:
    """Identify the current single-circle marker. A single circle marker followed
    by 5 circles is a 23, the one followed by 4 is a 15."""
    return 23 if len(markers_dictionary[(current_index + 1) % len(markers_dictionary)][0]) - 1 == 5 else 15

# Function for single circle based marker detection
def single_circle_based_marker_locater(gray_copy: np.ndarray) -> dict[tuple[int, int], int]:
    """Detect all markers' and circles' polygons, sort the markers' contours/polygons clockwise, and look for the
    marker wich has only one circle and has a visible successor (i.e., not covered by the glass).
    Identify the single-circle marker (15 or 23), and start indetifying all the markers from it."""
    _, threshold = cv.threshold(gray_copy, 194, 255, cv.THRESH_BINARY)

    contours, _ = cv.findContours(threshold, cv.RETR_TREE, cv.CHAIN_APPROX_SIMPLE)

    marker_contours = clockwise_sort_contours([
        cnt for cnt in contours if len(cv.approxPolyDP(cnt, 0.016 * cv.arcLength(cnt, True), True)) == 5 and cv.contourArea(cnt) > 1500
    ])

    circle_polys = [act_poly for cnt in contours if len(act_poly := cv.approxPolyDP(cnt, 0.016 * cv.arcLength(cnt, True), True)) > 5]

    marker_polys = [
        cv.approxPolyDP(marker_cnt, 0.016 * cv.arcLength(marker_cnt, True), True) for marker_cnt in marker_contours
    ]

    markers_dictionary = [
        [
            [act_marker] + [
                act_circle for act_circle in circle_polys if cv.pointPolygonTest(act_marker, (int(act_circle[0][0][0]), int(act_circle[0][0][1])), False) >= 0
            ]
        ]
        for act_marker in marker_polys
    ]

    point_to_id_map = {}
    for mac_index, marker_and_circles in enumerate(markers_dictionary):
        if len(marker_and_circles[0]) - 1 == 1 and markers_continuity_checker(markers_dictionary, mac_index):
            labeling_visit_index = mac_index
            num_of_visible_markers = len(markers_dictionary)
            last_label = single_cir_marker_locator(markers_dictionary=markers_dictionary, current_index=mac_index)
            is_clockwise = True
            single_circle_index = mac_index
            single_circle_label = last_label
            last_label -= 1
            for _ in range(1, num_of_visible_markers):
                last_label = (last_label + (1 if is_clockwise else -1)) % 24
                current_marker_corners = markers_dictionary[labeling_visit_index][0][0]
                index_of_concave = concave_ang_finder(current_marker_corners)
                tupled_point = (
                    current_marker_corners[index_of_concave][0][0],
                    current_marker_corners[index_of_concave][0][1],
                )
                point_to_id_map[tupled_point] = last_label
                right_continuity = markers_continuity_checker(markers_dictionary, labeling_visit_index) if is_clockwise else True
                if not right_continuity:
                    labeling_visit_index = (single_circle_index - 1) % num_of_visible_markers
                    is_clockwise = False
                    last_label = single_circle_label
                else:
                    labeling_visit_index = (labeling_visit_index + (1 if is_clockwise else -1)) % num_of_visible_markers
            return point_to_id_map
    return point_to_id_map

# Function for marker identification and tracking
def marker_detection(video_index: int) -> None:
    video_path = f"data/obj0{video_index}.mp4"
    with open(f"data/obj0{video_index}_marker.csv", "w") as fd:
        fd.write("FRAME,MARK_ID,Px,Py,X,Y,Z\n")

    vidcap = cv.VideoCapture(video_path)
    success, frame = vidcap.read()

    num_of_frames = int(vidcap.get(cv.CAP_PROP_FRAME_COUNT))

    lk_params = dict(
        winSize=(20, 20),
        maxLevel=1,
        criteria=(cv.TERM_CRITERIA_EPS | cv.TERM_CRITERIA_COUNT, 10, 0.03),
    )

    (out_h, out_w) = int(vidcap.get(cv.CAP_PROP_FRAME_HEIGHT)), int(vidcap.get(cv.CAP_PROP_FRAME_WIDTH))
    CROP_START, CROP_END = int(out_w / 1.641), int(out_w / 1.22)
    old_gray_frame = cv.cvtColor(frame[:, CROP_START:CROP_END], cv.COLOR_BGR2GRAY)

    fps = vidcap.get(cv.CAP_PROP_FPS)

    csv_row = ""

    rotated_labels = retrieve_labels()

    output_frames = []

    for frame_index in range(num_of_frames):
        if success:

            current_gray_frame = cv.cvtColor(frame[:, CROP_START:CROP_END], cv.COLOR_BGR2GRAY)
            if frame_index % 12 == 0:
                previous_frame_dict_temp = single_circle_based_marker_locater(gray_copy=current_gray_frame)
                previous_frame_dict = previous_frame_dict_temp if previous_frame_dict_temp != {} else previous_frame_dict

                p0 = np.array(
                    [np.array([(lab_point_tuple[0], lab_point_tuple[1])], dtype=np.float32) for lab_point_tuple in previous_frame_dict],
                    dtype=np.float32,
                )

            p1, st, _ = cv.calcOpticalFlowPyrLK(old_gray_frame, current_gray_frame, p0, None, **lk_params)

            if p1 is not None:
                good_new = p1[st == 1]
                good_old = p0[st == 1]

            current_frame_dict = {}
            for _, (current_point, old_point) in enumerate(zip(good_new, good_old)):

                a, b = current_point.astype(int)
                c, d = old_point.astype(int)
                label = previous_frame_dict[(c, d)]
                current_frame_dict[(a, b)] = label
                corrected_a = a + CROP_START
                csv_row += f"{frame_index},{label},{corrected_a},{b},{rotated_labels[label][0]},{rotated_labels[label][1]},0\n"

                frame = cv.putText(
                    img=frame,
                    text=str(label),
                    org=(corrected_a, b),
                    fontScale=1.3,
                    fontFace=cv.FONT_HERSHEY_SIMPLEX,
                    color=(0, 0, 0),
                    thickness=10,
                )

                frame = cv.putText(
                    img=frame,
                    text=str(label),
                    org=(corrected_a, b),
                    fontScale=1.3,
                    fontFace=cv.FONT_HERSHEY_SIMPLEX,
                    color=(255, 255, 255),
                    thickness=3,
                )

                frame = cv.circle(
                    frame,
                    (corrected_a, b),
                    radius=5,
                    color=(0, 0, 255),
                    thickness=3,
                )

            previous_frame_dict = current_frame_dict

            old_gray_frame = current_gray_frame
            p0 = good_new.reshape(-1, 1, 2)

            output_frames.append(frame)

            success, frame = vidcap.read()
        else:
            break
    vidcap.release()

    fourcc = cv.VideoWriter_fourcc("m", "p", "4", "v")

    out = cv.VideoWriter(
        f"data/obj0{video_index}_marker.mp4",
        fourcc,
        fps,
        (out_w, out_h),
    )

    for frame in output_frames:
        out.write(frame)
    out.release()

    with open(f"data/obj0{video_index}_marker.csv", "a") as fd:
        fd.write(csv_row)

# Choose video for processing
if __name__ == "__main__":
    print("Choose which video to process:")
    print("1. Video 1")
    print("2. Video 2")
    print("3. Video 3")
    print("4. Video 4")

    chosen_video = int(input("Enter the corresponding number: "))

    while chosen_video not in [1, 2, 3, 4]:
        chosen_video = int(input("Invalid input. Please enter a valid number: "))

    marker_detection(chosen_video)
