import cv2
import numpy as np

def select_video():
    while True:
        print("Select a video:")
        for i in range(1, 5):
            print(f"{i}. Video {i}")
        choice = input("Enter your choice (1-4): ")
        if choice in ['1', '2', '3', '4']:
            return int(choice)
        else:
            print("Invalid input. Please try again.")

# Map user choice to video file paths and output file names
video_paths = [
    r"F:\GEOMETRY AND 3D VISION\Project\New folder\Tasks\Segmentation\data\obj01.mp4",
    r"F:\GEOMETRY AND 3D VISION\Project\New folder\Tasks\Segmentation\data\obj02.mp4",
    r"F:\GEOMETRY AND 3D VISION\Project\New folder\Tasks\Segmentation\data\obj03.mp4",
    r"F:\GEOMETRY AND 3D VISION\Project\New folder\Tasks\Segmentation\data\obj04.mp4"
]

output_filenames = [
   r"F:\GEOMETRY AND 3D VISION\Project\New folder\Tasks\Segmentation\data\obj1_mask1.mp4",
   r"F:\GEOMETRY AND 3D VISION\Project\New folder\Tasks\Segmentation\data\obj2_mask1.mp4",
   r"F:\GEOMETRY AND 3D VISION\Project\New folder\Tasks\Segmentation\data\obj3_mask1.mp4",
   r"F:\GEOMETRY AND 3D VISION\Project\New folder\Tasks\Segmentation\data\obj4_mask1.mp4"
]

selected_video = select_video()

# Load the selected video
video_path = video_paths[selected_video - 1]
output_filename = output_filenames[selected_video - 1]

cap = cv2.VideoCapture(video_path)

# Define the codec and create a VideoWriter object
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
output_video = cv2.VideoWriter(output_filename, fourcc, 30.0, (int(cap.get(3)), int(cap.get(4))))

# Define the kernel for morphological operations
kernel = np.ones((5, 5), np.uint8)

while cap.isOpened():
    ret, frame = cap.read()

    if not ret:
        break

    # Convert the frame to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Apply thresholding
    _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)

    # Perform morphological operations to remove noise
    opening = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel, iterations=2)
    sure_bg = cv2.dilate(opening, kernel, iterations=3)

    # Find sure foreground using distance transform
    dist_transform = cv2.distanceTransform(opening, cv2.DIST_L2, 5)
    _, sure_fg = cv2.threshold(dist_transform, 0.7*dist_transform.max(), 255, 0)

    # Find unknown region
    sure_fg = np.uint8(sure_fg)
    unknown = cv2.subtract(sure_bg, sure_fg)

    # Marker labelling
    _, markers = cv2.connectedComponents(sure_fg)

    # Add one to all the labels so that sure background is not 0, but 1
    markers = markers + 1
    markers[unknown == 255] = 0

    # Apply watershed algorithm
    cv2.watershed(frame, markers)
    frame[markers == 1] = [255, 255, 255]  # Set the foreground to white
    frame[markers != 1] = [0, 0, 0]  # Set the background to black

    # Write the frame to the output video
    output_video.write(frame)

    # Display the resulting frame
    cv2.imshow('Frame', frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release video objects
cap.release()
output_video.release()

cv2.destroyAllWindows()
