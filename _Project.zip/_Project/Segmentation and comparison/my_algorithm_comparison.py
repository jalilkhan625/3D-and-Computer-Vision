import cv2
import os
import numpy as np

# Define the video and image paths
video_paths = [
    r"F:\GEOMETRY AND 3D VISION\Project\New folder\Tasks\Segmentation\data\obj1_mask.mp4",
    r"F:\GEOMETRY AND 3D VISION\Project\New folder\Tasks\Segmentation\data\obj2_mask.mp4",
    r"F:\GEOMETRY AND 3D VISION\Project\New folder\Tasks\Segmentation\data\obj3_mask.mp4",
    r"F:\GEOMETRY AND 3D VISION\Project\New folder\Tasks\Segmentation\data\obj4_mask.mp4"
]

image_folder_paths = [
    r"F:\GEOMETRY AND 3D VISION\Project\New folder\Tasks\Segmentation\obj01",
    r"F:\GEOMETRY AND 3D VISION\Project\New folder\Tasks\Segmentation\obj02",
    r"F:\GEOMETRY AND 3D VISION\Project\New folder\Tasks\Segmentation\obj03",
    r"F:\GEOMETRY AND 3D VISION\Project\New folder\Tasks\Segmentation\obj04"
]

def select_video():
    print("Please select a video:")
    for i, path in enumerate(video_paths, start=1):
        print(f"{i}. Video {i}")

    choice = input("Enter the number of the video you want to select (1-4): ")

    if choice in ['1', '2', '3', '4']:
        return int(choice)
    else:
        print("Invalid choice. Please try again.")
        return select_video()

def process_video(video_path, image_folder_path):
    cap = cv2.VideoCapture(video_path)
    frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    # Initialize counters for true positives, true negatives, false positives, and false negatives
    true_positives = true_negatives = false_positives = false_negatives = 0

    # Process frames
    for i in range(frame_count):
        ret, frame = cap.read()
        if not ret:
            break

        # Convert the frame to grayscale for comparison
        gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Load the corresponding image
        image_filename = f"{i:06d}_mask.png"
        image_path = os.path.join(image_folder_path, image_filename)

        if os.path.isfile(image_path):
            image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

            # Apply thresholding to images
            _, thresholded_image = cv2.threshold(image, 1, 255, cv2.THRESH_BINARY)
            _, thresholded_frame = cv2.threshold(gray_frame, 1, 255, cv2.THRESH_BINARY)

            # Calculate True Positives, True Negatives, False Positives, False Negatives
            true_positives += np.sum(cv2.bitwise_and(thresholded_frame, thresholded_image) == 255)
            true_negatives += np.sum(cv2.bitwise_and(thresholded_frame, thresholded_image) == 0)
            false_positives += np.sum(cv2.bitwise_and(thresholded_frame, cv2.bitwise_not(thresholded_image)) == 255)
            false_negatives += np.sum(cv2.bitwise_and(cv2.bitwise_not(thresholded_frame), thresholded_image) == 255)

    cap.release()

    # Compute precision, recall, and accuracy
    precision = true_positives / (true_positives + false_positives) if (true_positives + false_positives) > 0 else 0.0
    recall = true_positives / (true_positives + false_negatives) if (true_positives + false_negatives) > 0 else 0.0
    accuracy = (true_positives + true_negatives) / (true_positives + true_negatives + false_positives + false_negatives) if (true_positives + true_negatives + false_positives + false_negatives) > 0 else 0.0

    # Print results
    print(f"True Positives: {true_positives}")
    print(f"True Negatives: {true_negatives}")
    print(f"False Positives: {false_positives}")
    print(f"False Negatives: {false_negatives}")
    print(f"Precision: {precision:.2f}")
    print(f"Recall: {recall:.2f}")
    print(f"Accuracy: {accuracy:.2f}")

if __name__ == "__main__":
    selected_video = select_video()
    selected_video -= 1  # Adjust index for list
    process_video(video_paths[selected_video], image_folder_paths[selected_video])
