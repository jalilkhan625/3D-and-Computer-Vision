import cv2
import numpy as np

def process_frame(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    _, thresh = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    kernel = np.ones((3, 3), np.uint8)
    opening = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel, iterations=2)
    sure_bg = cv2.dilate(opening, kernel, iterations=3)
    _, markers = cv2.connectedComponents(sure_bg)
    result = np.where(markers == 1, 0, 255).astype(np.uint8)
    result = cv2.cvtColor(result, cv2.COLOR_GRAY2BGR)
    return result

video_paths = [
    r"F:\GEOMETRY AND 3D VISION\Project\data\obj01.mp4",
    r"F:\GEOMETRY AND 3D VISION\Project\data\obj02.mp4",
    r"F:\GEOMETRY AND 3D VISION\Project\data\obj03.mp4",
    r"F:\GEOMETRY AND 3D VISION\Project\data\obj04.mp4"
]

print("Select a video to play:")
for i, path in enumerate(video_paths, 1):
    print(f"{i}. Video {i}")

choice = int(input("Enter your choice (1-4): "))

if choice < 1 or choice > len(video_paths):
    print("Invalid choice. Exiting...")
    exit()

video_path = video_paths[choice - 1]
cap = cv2.VideoCapture(video_path)

output_video_path = r"F:\GEOMETRY AND 3D VISION\Project\New folder\Tasks\Segmentation\data\obj{}_mask.mp4".format(choice)
width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
fps = int(cap.get(cv2.CAP_PROP_FPS))
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
out = cv2.VideoWriter(output_video_path, fourcc, fps, (width, height))

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    result_frame = process_frame(frame)

    out.write(result_frame)

    reduced_frame = cv2.resize(result_frame, (0, 0), fx=0.5, fy=0.5)

    #cv2.imshow(f'Segmented Video {choice}', reduced_frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

out.release()
cap.release()
cv2.destroyAllWindows()
